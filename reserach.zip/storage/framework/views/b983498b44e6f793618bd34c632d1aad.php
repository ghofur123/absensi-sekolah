<div
    class="fi-in-placeholder text-sm leading-6 text-gray-400 dark:text-gray-500"
>
    <?php echo e($slot); ?>

</div>
<?php /**PATH D:\INSTALLAPLIKASI\laragon\www\PHP8.2.29\absensi-sekolah\vendor\filament\infolists\resources\views\components\entries\placeholder.blade.php ENDPATH**/ ?>