<!DOCTYPE html>
<html>

<head>
    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
            font-size: 11px;
        }

        h3 {
            text-align: center;
            margin-bottom: 15px;
        }

        table {
            width: 100%;
            border-spacing: 10px;
        }

        td {
            width: 33.33%;
            vertical-align: top;
        }

        .card {
            border: 1px solid #000;
            padding: 10px;
            text-align: center;
            height: 230px;
        }

        .lembaga {
            font-weight: bold;
            font-size: 12px;
            margin-bottom: 6px;
            text-transform: uppercase;
        }

        .nama {
            font-weight: bold;
            font-size: 13px;
            margin-bottom: 4px;
        }

        .info {
            margin-bottom: 3px;
        }

        .qr {
            margin-top: 8px;
        }
    </style>
</head>

<body>

    <h3>KARTU SISWA – <?php echo e(strtoupper($kelas->lembaga->nama_lembaga)); ?></h3>

    <table>
        <tr>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td>
                <div class="card">
                    <div class="lembaga">
                        <?php echo e($kelas->lembaga->nama_lembaga); ?>

                    </div>

                    <div class="nama"><?php echo e($siswa->nama_siswa); ?></div>
                    <div class="info">NISN: <?php echo e($siswa->nisn); ?></div>
                    <div class="info">Kelas: <?php echo e($kelas->nama_kelas); ?></div>

                    <div class="qr">
                        <img src="data:image/png;base64,<?php echo e($qrs[$siswa->id]); ?>" width="100">
                    </div>
                </div>
            </td>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(($index + 1) % 3 == 0): ?>
        </tr>
        <tr>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </tr>
    </table>

</body>

</html><?php /**PATH D:\INSTALLAPLIKASI\laragon\www\PHP8.2.29\absensi-sekolah\resources\views\pdf\kartu-siswa.blade.php ENDPATH**/ ?>