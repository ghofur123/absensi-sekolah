<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.absensi-guru-resource.pages.create-absensi-guru' => 'App\\Filament\\Resources\\AbsensiGuruResource\\Pages\\CreateAbsensiGuru',
    'app.filament.resources.absensi-guru-resource.pages.edit-absensi-guru' => 'App\\Filament\\Resources\\AbsensiGuruResource\\Pages\\EditAbsensiGuru',
    'app.filament.resources.absensi-guru-resource.pages.list-absensi-gurus' => 'App\\Filament\\Resources\\AbsensiGuruResource\\Pages\\ListAbsensiGurus',
    'app.filament.resources.absensi-resource.pages.create-absensi' => 'App\\Filament\\Resources\\AbsensiResource\\Pages\\CreateAbsensi',
    'app.filament.resources.absensi-resource.pages.edit-absensi' => 'App\\Filament\\Resources\\AbsensiResource\\Pages\\EditAbsensi',
    'app.filament.resources.absensi-resource.pages.list-absensis' => 'App\\Filament\\Resources\\AbsensiResource\\Pages\\ListAbsensis',
    'app.filament.resources.guru-resource.pages.create-guru' => 'App\\Filament\\Resources\\GuruResource\\Pages\\CreateGuru',
    'app.filament.resources.guru-resource.pages.edit-guru' => 'App\\Filament\\Resources\\GuruResource\\Pages\\EditGuru',
    'app.filament.resources.guru-resource.pages.list-gurus' => 'App\\Filament\\Resources\\GuruResource\\Pages\\ListGurus',
    'app.filament.resources.jadwal-resource.pages.create-jadwal' => 'App\\Filament\\Resources\\JadwalResource\\Pages\\CreateJadwal',
    'app.filament.resources.jadwal-resource.pages.edit-jadwal' => 'App\\Filament\\Resources\\JadwalResource\\Pages\\EditJadwal',
    'app.filament.resources.jadwal-resource.pages.list-jadwals' => 'App\\Filament\\Resources\\JadwalResource\\Pages\\ListJadwals',
    'app.filament.resources.kelas-resource.pages.create-kelas' => 'App\\Filament\\Resources\\KelasResource\\Pages\\CreateKelas',
    'app.filament.resources.kelas-resource.pages.edit-kelas' => 'App\\Filament\\Resources\\KelasResource\\Pages\\EditKelas',
    'app.filament.resources.kelas-resource.pages.list-kelas' => 'App\\Filament\\Resources\\KelasResource\\Pages\\ListKelas',
    'app.filament.resources.lembaga-resource.pages.create-lembaga' => 'App\\Filament\\Resources\\LembagaResource\\Pages\\CreateLembaga',
    'app.filament.resources.lembaga-resource.pages.edit-lembaga' => 'App\\Filament\\Resources\\LembagaResource\\Pages\\EditLembaga',
    'app.filament.resources.lembaga-resource.pages.list-lembagas' => 'App\\Filament\\Resources\\LembagaResource\\Pages\\ListLembagas',
    'app.filament.resources.lembaga-setting-resource.pages.create-lembaga-setting' => 'App\\Filament\\Resources\\LembagaSettingResource\\Pages\\CreateLembagaSetting',
    'app.filament.resources.lembaga-setting-resource.pages.edit-lembaga-setting' => 'App\\Filament\\Resources\\LembagaSettingResource\\Pages\\EditLembagaSetting',
    'app.filament.resources.lembaga-setting-resource.pages.list-lembaga-settings' => 'App\\Filament\\Resources\\LembagaSettingResource\\Pages\\ListLembagaSettings',
    'app.filament.resources.mata-pelajaran-resource.pages.create-mata-pelajaran' => 'App\\Filament\\Resources\\MataPelajaranResource\\Pages\\CreateMataPelajaran',
    'app.filament.resources.mata-pelajaran-resource.pages.edit-mata-pelajaran' => 'App\\Filament\\Resources\\MataPelajaranResource\\Pages\\EditMataPelajaran',
    'app.filament.resources.mata-pelajaran-resource.pages.list-mata-pelajarans' => 'App\\Filament\\Resources\\MataPelajaranResource\\Pages\\ListMataPelajarans',
    'app.filament.resources.qr-scaner-resource.pages.create-qr-scaner' => 'App\\Filament\\Resources\\QrScanerResource\\Pages\\CreateQrScaner',
    'app.filament.resources.qr-scaner-resource.pages.edit-qr-scaner' => 'App\\Filament\\Resources\\QrScanerResource\\Pages\\EditQrScaner',
    'app.filament.resources.qr-scaner-resource.pages.list-qr-scaners' => 'App\\Filament\\Resources\\QrScanerResource\\Pages\\ListQrScaners',
    'app.filament.resources.role-resource.pages.create-role' => 'App\\Filament\\Resources\\RoleResource\\Pages\\CreateRole',
    'app.filament.resources.role-resource.pages.edit-role' => 'App\\Filament\\Resources\\RoleResource\\Pages\\EditRole',
    'app.filament.resources.role-resource.pages.list-roles' => 'App\\Filament\\Resources\\RoleResource\\Pages\\ListRoles',
    'app.filament.resources.role-resource.pages.view-role' => 'App\\Filament\\Resources\\RoleResource\\Pages\\ViewRole',
    'app.filament.resources.siswa-resource.pages.create-siswa' => 'App\\Filament\\Resources\\SiswaResource\\Pages\\CreateSiswa',
    'app.filament.resources.siswa-resource.pages.edit-siswa' => 'App\\Filament\\Resources\\SiswaResource\\Pages\\EditSiswa',
    'app.filament.resources.siswa-resource.pages.list-siswas' => 'App\\Filament\\Resources\\SiswaResource\\Pages\\ListSiswas',
    'app.filament.resources.user-resource.pages.create-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\CreateUser',
    'app.filament.resources.user-resource.pages.edit-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\EditUser',
    'app.filament.resources.user-resource.pages.list-users' => 'App\\Filament\\Resources\\UserResource\\Pages\\ListUsers',
    'app.filament.resources.wa-send-resource.pages.create-wa-send' => 'App\\Filament\\Resources\\WaSendResource\\Pages\\CreateWaSend',
    'app.filament.resources.wa-send-resource.pages.edit-wa-send' => 'App\\Filament\\Resources\\WaSendResource\\Pages\\EditWaSend',
    'app.filament.resources.wa-send-resource.pages.list-wa-sends' => 'App\\Filament\\Resources\\WaSendResource\\Pages\\ListWaSends',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'app.filament.widgets.absensi-hari-ini-widget' => 'App\\Filament\\Widgets\\AbsensiHariIniWidget',
    'app.filament.widgets.absensi-mingguan-chart' => 'App\\Filament\\Widgets\\AbsensiMingguanChart',
    'app.filament.widgets.alarm-absensi-widget' => 'App\\Filament\\Widgets\\AlarmAbsensiWidget',
    'app.filament.widgets.siswa-berisiko-widget' => 'App\\Filament\\Widgets\\SiswaBerisikoWidget',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.pages.auth.login' => 'Filament\\Pages\\Auth\\Login',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'D:\\INSTALLAPLIKASI\\laragon\\www\\PHP8.2.29\\absensi-sekolah\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'D:\\INSTALLAPLIKASI\\laragon\\www\\PHP8.2.29\\absensi-sekolah\\app\\Filament\\Resources\\AbsensiGuruResource.php' => 'App\\Filament\\Resources\\AbsensiGuruResource',
    'D:\\INSTALLAPLIKASI\\laragon\\www\\PHP8.2.29\\absensi-sekolah\\app\\Filament\\Resources\\AbsensiResource.php' => 'App\\Filament\\Resources\\AbsensiResource',
    'D:\\INSTALLAPLIKASI\\laragon\\www\\PHP8.2.29\\absensi-sekolah\\app\\Filament\\Resources\\GuruResource.php' => 'App\\Filament\\Resources\\GuruResource',
    'D:\\INSTALLAPLIKASI\\laragon\\www\\PHP8.2.29\\absensi-sekolah\\app\\Filament\\Resources\\JadwalResource.php' => 'App\\Filament\\Resources\\JadwalResource',
    'D:\\INSTALLAPLIKASI\\laragon\\www\\PHP8.2.29\\absensi-sekolah\\app\\Filament\\Resources\\KelasResource.php' => 'App\\Filament\\Resources\\KelasResource',
    'D:\\INSTALLAPLIKASI\\laragon\\www\\PHP8.2.29\\absensi-sekolah\\app\\Filament\\Resources\\LembagaResource.php' => 'App\\Filament\\Resources\\LembagaResource',
    'D:\\INSTALLAPLIKASI\\laragon\\www\\PHP8.2.29\\absensi-sekolah\\app\\Filament\\Resources\\LembagaSettingResource.php' => 'App\\Filament\\Resources\\LembagaSettingResource',
    'D:\\INSTALLAPLIKASI\\laragon\\www\\PHP8.2.29\\absensi-sekolah\\app\\Filament\\Resources\\MataPelajaranResource.php' => 'App\\Filament\\Resources\\MataPelajaranResource',
    'D:\\INSTALLAPLIKASI\\laragon\\www\\PHP8.2.29\\absensi-sekolah\\app\\Filament\\Resources\\RoleResource.php' => 'App\\Filament\\Resources\\RoleResource',
    'D:\\INSTALLAPLIKASI\\laragon\\www\\PHP8.2.29\\absensi-sekolah\\app\\Filament\\Resources\\SiswaResource.php' => 'App\\Filament\\Resources\\SiswaResource',
    'D:\\INSTALLAPLIKASI\\laragon\\www\\PHP8.2.29\\absensi-sekolah\\app\\Filament\\Resources\\UserResource.php' => 'App\\Filament\\Resources\\UserResource',
    'D:\\INSTALLAPLIKASI\\laragon\\www\\PHP8.2.29\\absensi-sekolah\\app\\Filament\\Resources\\WaSendResource.php' => 'App\\Filament\\Resources\\WaSendResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'D:\\INSTALLAPLIKASI\\laragon\\www\\PHP8.2.29\\absensi-sekolah\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    'D:\\INSTALLAPLIKASI\\laragon\\www\\PHP8.2.29\\absensi-sekolah\\app\\Filament\\Widgets\\AbsensiHariIniWidget.php' => 'App\\Filament\\Widgets\\AbsensiHariIniWidget',
    'D:\\INSTALLAPLIKASI\\laragon\\www\\PHP8.2.29\\absensi-sekolah\\app\\Filament\\Widgets\\AbsensiMingguanChart.php' => 'App\\Filament\\Widgets\\AbsensiMingguanChart',
    'D:\\INSTALLAPLIKASI\\laragon\\www\\PHP8.2.29\\absensi-sekolah\\app\\Filament\\Widgets\\AlarmAbsensiWidget.php' => 'App\\Filament\\Widgets\\AlarmAbsensiWidget',
    'D:\\INSTALLAPLIKASI\\laragon\\www\\PHP8.2.29\\absensi-sekolah\\app\\Filament\\Widgets\\SiswaBerisikoWidget.php' => 'App\\Filament\\Widgets\\SiswaBerisikoWidget',
    0 => 'App\\Filament\\Widgets\\AbsensiHariIniWidget',
    1 => 'App\\Filament\\Widgets\\AbsensiMingguanChart',
    2 => 'App\\Filament\\Widgets\\SiswaBerisikoWidget',
    3 => 'App\\Filament\\Widgets\\AlarmAbsensiWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => 'D:\\INSTALLAPLIKASI\\laragon\\www\\PHP8.2.29\\absensi-sekolah\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);