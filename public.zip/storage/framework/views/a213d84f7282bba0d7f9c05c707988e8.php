<h3
    <?php echo e($attributes->class(['fi-section-header-heading text-base font-semibold leading-6 text-gray-950 dark:text-white'])); ?>

>
    <?php echo e($slot); ?>

</h3>
<?php /**PATH D:\INSTALLAPLIKASI\laragon\www\PHP8.2.29\absensi-sekolah\vendor\filament\support\resources\views\components\section\heading.blade.php ENDPATH**/ ?>