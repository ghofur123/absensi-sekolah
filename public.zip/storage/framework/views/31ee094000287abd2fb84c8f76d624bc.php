<div x-data="{
    statePath: <?php echo \Illuminate\Support\Js::from($statePath)->toHtml() ?>,
    isHeaderAction: <?php echo \Illuminate\Support\Js::from($isHeaderAction ?? false)->toHtml() ?>,
    hasPhpModifier: <?php echo \Illuminate\Support\Js::from($hasPhpModifier ?? false)->toHtml() ?>,
    stateModifierJs: <?php echo \Illuminate\Support\Js::from($stateModifierJs)->toHtml() ?>,
    supportedFormats: <?php echo \Illuminate\Support\Js::from($supportedFormats)->toHtml() ?>,
    messages: {
        cameraUnavailable: <?php echo \Illuminate\Support\Js::from($cameraUnavailableMessage)->toHtml() ?>,
        permissionDenied: <?php echo \Illuminate\Support\Js::from($permissionDeniedMessage)->toHtml() ?>,
        browserNotSupported: <?php echo \Illuminate\Support\Js::from(__('Your browser does not support camera access.'))->toHtml() ?>,
        cameraConstraints: <?php echo \Illuminate\Support\Js::from(__('The selected camera does not meet the requirements.'))->toHtml() ?>,
    },
    isScanning: false,
    isLoading: false,
    cameraError: false,
    cameraErrorMessage: '',
    scanner: null,
    cameras: [],
    currentCameraIndex: 0,
    currentCameraLabel: '',

    init() {
        this.startScanning();
    },

    destroy() {
        this.stopScanningSync();
    },

    stopScanningSync() {
        if (this.scanner) {
            try {
                this.scanner.stop().catch(() => {});
                this.scanner.clear();
            } catch (e) {
                // Ignore errors during cleanup
            }
            this.scanner = null;
        }
        this.isScanning = false;
    },

    sanitizeScannedText(text) {
        if (typeof text !== 'string') {
            return '';
        }
        return text.replace(/<[^>]*>/g, '').trim();
    },

    applyStateModifier(value, formatId) {
        if (!this.stateModifierJs) {
            return value;
        }

        try {
            const modifierFn = new Function('return ' + this.stateModifierJs)();
            return modifierFn(value, formatId);
        } catch (error) {
            console.warn('Error applying state modifier:', error);
            return value;
        }
    },

    async loadHtml5Qrcode() {
        if (window.Html5Qrcode) {
            return true;
        }

        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = 'https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js';
            script.onload = () => resolve(true);
            script.onerror = () => reject(new Error('Failed to load scanner library'));
            document.head.appendChild(script);
        });
    },

    async startScanning() {
        this.isLoading = true;
        this.cameraError = false;
        this.cameraErrorMessage = '';

        try {
            await this.loadHtml5Qrcode();

            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                throw new Error('camera_unavailable');
            }

            this.cameras = await Html5Qrcode.getCameras();

            if (!this.cameras || this.cameras.length === 0) {
                throw new Error('camera_unavailable');
            }

            this.isScanning = true;

            await this.$nextTick();

            const containerId = this.$refs.scannerContainer.id || 'barcode-scanner-modal-container';
            this.$refs.scannerContainer.id = containerId;

            this.scanner = new Html5Qrcode(containerId);

            const preferredCamera = this.cameras.find(c =>
                c.label.toLowerCase().includes('back') ||
                c.label.toLowerCase().includes('rear') ||
                c.label.toLowerCase().includes('environment')
            );

            this.currentCameraIndex = preferredCamera ?
                this.cameras.indexOf(preferredCamera) :
                0;

            await this.startCamera();

        } catch (error) {
            this.handleError(error);
        } finally {
            this.isLoading = false;
        }
    },

    async startCamera() {
        if (!this.scanner || !this.cameras.length) return;

        const camera = this.cameras[this.currentCameraIndex];
        this.currentCameraLabel = camera.label ||
            `Camera ${this.currentCameraIndex + 1}`;

        const config = {
            fps: 10,
            formatsToSupport: this.supportedFormats,
        };

        try {
            await this.scanner.start(
                camera.id,
                config,
                (decodedText, decodedResult) => this.onScanSuccess(decodedText, decodedResult),
                (errorMessage) => {}
            );
        } catch (error) {
            this.handleError(error);
        }
    },

    async stopScanning() {
        if (this.scanner) {
            try {
                const scannerState = this.scanner.getState();
                if (scannerState === Html5QrcodeScannerState.SCANNING ||
                    scannerState === Html5QrcodeScannerState.PAUSED) {
                    await this.scanner.stop();
                }
                await this.scanner.clear();
            } catch (error) {
                console.warn('Error stopping scanner:', error);
                try {
                    await this.scanner.clear();
                } catch (clearError) {
                    console.warn('Error clearing scanner:', clearError);
                }
            }
            this.scanner = null;
        }
        this.isScanning = false;
        this.isLoading = false;
    },

    async switchCamera() {
        if (this.cameras.length <= 1 || this.isLoading) return;

        this.isLoading = true;

        try {
            if (this.scanner) {
                try {
                    await this.scanner.stop();
                } catch (stopError) {
                    // Ignore stop errors - scanner might already be stopped
                }
                try {
                    this.scanner.clear();
                } catch (clearError) {
                    // Ignore clear errors
                }
                this.scanner = null;
            }

            await new Promise(resolve => setTimeout(resolve, 150));

            this.currentCameraIndex = (this.currentCameraIndex + 1) % this.cameras.length;

            const containerId = this.$refs.scannerContainer.id;
            this.scanner = new Html5Qrcode(containerId);

            await this.startCamera();
        } catch (error) {
            if (!error.message?.includes('removeChild') && !error.message?.includes('clear')) {
                this.handleError(error);
            }
        } finally {
            this.isLoading = false;
        }
    },

    async onScanSuccess(decodedText, decodedResult) {
        const sanitizedText = this.sanitizeScannedText(decodedText);
        const formatId = decodedResult?.result?.format?.format ?? 0;

        // Stop camera first, then wait a moment for media cleanup
        await this.stopScanning();
        await new Promise(resolve => setTimeout(resolve, 50));

        if (this.isHeaderAction) {
            // Header action - custom callback with redirect support
            $wire.processBarcodeScanHeader(sanitizedText, formatId)
                .then(response => {
                    if (response && response.redirect) {
                        window.location.href = response.redirect;
                        return;
                    }
                    this.closeModal();
                });
        } else if (this.hasPhpModifier) {
            // Form action - PHP closure via Livewire
            $wire.processBarcodeScan(this.statePath, sanitizedText, formatId)
                .then(modifiedValue => {
                    if (this.statePath) {
                        $wire.set(this.statePath, modifiedValue);
                    }
                    this.closeModal();
                });
        } else {
            // Form action - JS modifier or no modifier
            const modifiedValue = this.applyStateModifier(sanitizedText, formatId);
            if (this.statePath) {
                $wire.set(this.statePath, modifiedValue);
            }
            this.closeModal();
        }
    },

    closeModal() {
        if (this.isHeaderAction) {
            if (typeof $wire.unmountAction === 'function') {
                $wire.unmountAction(false);
            }
        } else {
            if (typeof $wire.unmountFormComponentAction === 'function') {
                $wire.unmountFormComponentAction(false);
            } else if (typeof $wire.unmountAction === 'function') {
                $wire.unmountAction(false);
            }
        }
    },

    handleError(error) {
        this.isScanning = false;
        this.isLoading = false;
        this.cameraError = true;

        const errorString = error.message || error.toString();

        if (errorString.includes('NotSupportedError')) {
            this.cameraErrorMessage = this.messages.browserNotSupported;
        } else if (errorString.includes('OverconstrainedError')) {
            this.cameraErrorMessage = this.messages.cameraConstraints;
        } else if (errorString.includes('Permission') ||
            errorString.includes('NotAllowedError') ||
            errorString.includes('denied')) {
            this.cameraErrorMessage = this.messages.permissionDenied;
        } else if (errorString.includes('camera_unavailable') ||
            errorString.includes('NotFoundError') ||
            errorString.includes('NotReadableError')) {
            this.cameraErrorMessage = this.messages.cameraUnavailable;
        } else {
            this.cameraErrorMessage = this.messages.cameraUnavailable;
        }

        console.warn('Barcode scanner error:', error);
    }
}"
    x-on:modal-closed.window="stopScanning()"
    x-on:close-modal.window="stopScanning()"
    x-on:open-modal.window="if ($event.detail.id !== 'barcode-scanner') stopScanning()"
    class="space-y-4">
    <div x-show="cameraError" role="alert" aria-live="assertive"
        class="rounded-lg bg-warning-50 p-4 dark:bg-warning-400/10">
        <div class="flex">
            <div class="flex-shrink-0">
                <?php if (isset($component)) { $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.icon','data' => ['icon' => 'heroicon-m-exclamation-triangle','class' => 'h-5 w-5 text-warning-400','ariaHidden' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'heroicon-m-exclamation-triangle','class' => 'h-5 w-5 text-warning-400','aria-hidden' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $attributes = $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $component = $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
            </div>
            <div class="ml-3">
                <p class="text-sm text-warning-700 dark:text-warning-400" x-text="cameraErrorMessage"></p>
                <button type="button" x-on:click="startScanning()"
                    class="mt-2 text-sm font-medium text-primary-600 hover:text-primary-500 dark:text-primary-400">
                    <?php echo e(__('Try Again')); ?>

                </button>
            </div>
        </div>
    </div>

    <div x-show="isScanning || isLoading" class="space-y-3">
        <div x-ref="scannerContainer" role="region" aria-live="polite"
            aria-label="<?php echo e(__('Barcode scanner camera preview')); ?>"
            class="relative overflow-hidden rounded-lg border border-gray-300 bg-gray-100 dark:border-gray-700 dark:bg-gray-800"
            style="min-height: 300px;">
            <div x-show="isLoading && !isScanning"
                class="absolute inset-0 flex items-center justify-center bg-gray-100 dark:bg-gray-800">
                <?php if (isset($component)) { $__componentOriginalbef7c2371a870b1887ec3741fe311a10 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbef7c2371a870b1887ec3741fe311a10 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.loading-indicator','data' => ['class' => 'h-8 w-8 text-primary-500','ariaLabel' => ''.e(__('Loading camera...')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::loading-indicator'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-8 w-8 text-primary-500','aria-label' => ''.e(__('Loading camera...')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbef7c2371a870b1887ec3741fe311a10)): ?>
<?php $attributes = $__attributesOriginalbef7c2371a870b1887ec3741fe311a10; ?>
<?php unset($__attributesOriginalbef7c2371a870b1887ec3741fe311a10); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbef7c2371a870b1887ec3741fe311a10)): ?>
<?php $component = $__componentOriginalbef7c2371a870b1887ec3741fe311a10; ?>
<?php unset($__componentOriginalbef7c2371a870b1887ec3741fe311a10); ?>
<?php endif; ?>
            </div>
        </div>

        <div class="flex items-center justify-between">
            <button type="button" x-show="cameras.length > 1" x-on:click="switchCamera()" x-bind:disabled="isLoading"
                aria-label="<?php echo e($switchCameraLabel); ?>"
                class="fi-btn fi-btn-size-sm fi-color-custom fi-btn-color-gray fi-color-gray fi-size-sm relative inline-grid grid-flow-col items-center justify-center gap-1 rounded-lg bg-white px-2 py-1.5 text-xs font-semibold text-gray-950 shadow-sm outline-none ring-1 ring-gray-950/10 transition duration-75 hover:bg-gray-50 focus-visible:ring-2 disabled:cursor-not-allowed disabled:opacity-50 dark:bg-white/5 dark:text-white dark:ring-white/20 dark:hover:bg-white/10">
                <?php if (isset($component)) { $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.icon','data' => ['icon' => 'heroicon-m-arrow-path','class' => 'h-4 w-4','ariaHidden' => 'true','xBind:class' => '{ \'animate-spin\': isLoading }']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'heroicon-m-arrow-path','class' => 'h-4 w-4','aria-hidden' => 'true','x-bind:class' => '{ \'animate-spin\': isLoading }']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $attributes = $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $component = $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
                <span><?php echo e($switchCameraLabel); ?></span>
            </button>

            <span x-show="cameras.length > 1" class="text-xs text-gray-500 dark:text-gray-400"
                x-text="currentCameraLabel" aria-live="polite"></span>
        </div>
    </div>
</div>
<?php /**PATH D:\INSTALLAPLIKASI\laragon\www\PHP8.2.29\absensi-sekolah\vendor\chengkangzai\filament-qrcode-scanner-html5\resources\views\barcode-scanner-modal.blade.php ENDPATH**/ ?>