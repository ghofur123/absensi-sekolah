<?php

namespace App\Filament\Resources\QrScanerResource\Pages;

use App\Filament\Resources\QrScanerResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateQrScaner extends CreateRecord
{
    protected static string $resource = QrScanerResource::class;
}
