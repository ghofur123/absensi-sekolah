<?php

namespace App\Filament\Resources\AbsensiGuruResource\Pages;

use App\Filament\Resources\AbsensiGuruResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAbsensiGuru extends CreateRecord
{
    protected static string $resource = AbsensiGuruResource::class;
}
