<?php

namespace App\Filament\Resources\LembagaSettingResource\Pages;

use App\Filament\Resources\LembagaSettingResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateLembagaSetting extends CreateRecord
{
    protected static string $resource = LembagaSettingResource::class;
}
