<?php

namespace App\Filament\Resources\WaSendResource\Pages;

use App\Filament\Resources\WaSendResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateWaSend extends CreateRecord
{
    protected static string $resource = WaSendResource::class;
}
