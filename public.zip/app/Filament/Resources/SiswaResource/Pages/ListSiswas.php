<?php

namespace App\Filament\Resources\SiswaResource\Pages;

use App\Filament\Resources\SiswaResource;
use App\Imports\SiswaImport;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;
use Maatwebsite\Excel\Facades\Excel;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Select;
use App\Models\Lembaga;
use App\Models\Kelas;
use Filament\Actions\Action;
use Illuminate\Support\Facades\Storage;

class ListSiswas extends ListRecords
{
    protected static string $resource = SiswaResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\Action::make('importSiswa')
                ->label('Import Excel')
                ->icon('heroicon-o-arrow-up-tray')
                ->slideOver()
                ->form([
                    Select::make('lembaga_id')
                        ->label('Lembaga')
                        ->options(Lembaga::pluck('nama_lembaga', 'id'))
                        ->required(),

                    Select::make('kelas_id')
                        ->label('Kelas')
                        ->options(Kelas::pluck('nama_kelas', 'id'))
                        ->required(),

                    FileUpload::make('file')
                        ->label('File Excel')
                        ->acceptedFileTypes([
                            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
                        ])
                        ->disk('local')
                        ->required(),
                ])
                ->action(function (array $data) {
                    Excel::import(
                        new SiswaImport(
                            $data['lembaga_id'],
                            $data['kelas_id']
                        ),
                        Storage::disk('local')->path($data['file'])
                    );
                }),
            Actions\CreateAction::make(),
            Action::make('downloadTemplate')
                ->label('Download Template')
                ->url(url('/download-template/siswa'))
                ->openUrlInNewTab(),
        ];
    }
}
